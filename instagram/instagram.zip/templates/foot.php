
<footer>
    <nav class="navbar fixed-bottom justify-content-center">
        <ul class="nav">
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>ABOUT US</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>SUPPORT</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>BLOG</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>PRESS</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>API</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>JOBS</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>PRIVACY</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>TERMS</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>DIRECTORY</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>PROFILES</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>HASHTAGS</small></a></li>
            <li class="nav-item"><a href="" class="nav-link" style="color: darkblue;"><small>LANGUAGE</small></a></li>
            <li class="nav-item"><span class="navbar-text"><strong style="color: gray;"><small>@2018 INSTAGRAM</small></strong></span></li>
        </ul>
    </nav>
</footer>